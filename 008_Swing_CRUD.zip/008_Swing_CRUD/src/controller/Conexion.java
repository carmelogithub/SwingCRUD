package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

	//variable de clase, global
	
	public Connection conectar() {
		Connection DbConnection = null; //variable de m�todo
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");//esta no est� depreciada
		DbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/wbeducar_java","root","");
	} 		catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 		catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		return DbConnection;
	}
	
	
}//cierra class
