package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.Conexion;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;


public class Login {

	private JFrame frmAccesoASistema;
	private JTextField usuario_txt;
	private JTextField password_txt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmAccesoASistema.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAccesoASistema = new JFrame();
		frmAccesoASistema.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 16));
		frmAccesoASistema.getContentPane().setBackground(new Color(0, 204, 255));
		frmAccesoASistema.setBackground(new Color(0, 153, 255));
		frmAccesoASistema.setTitle("Acceso a sistema");
		frmAccesoASistema.setBounds(100, 100, 450, 300);
		frmAccesoASistema.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAccesoASistema.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Usuario");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(65, 25, 80, 14);
		frmAccesoASistema.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Contrase\u00F1a");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(65, 73, 104, 14);
		frmAccesoASistema.getContentPane().add(lblNewLabel_1);
		
		usuario_txt = new JTextField();
		usuario_txt.setBounds(202, 22, 171, 20);
		frmAccesoASistema.getContentPane().add(usuario_txt);
		usuario_txt.setColumns(10);
		
		password_txt = new JTextField();
		password_txt.setBounds(202, 70, 171, 20);
		frmAccesoASistema.getContentPane().add(password_txt);
		password_txt.setColumns(10);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("bot�n Reset pulsado");
				usuario_txt.setText("");
				password_txt.setText("");
			}
		});
		btnReset.setBounds(183, 142, 89, 23);
		frmAccesoASistema.getContentPane().add(btnReset);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("bot�n Login pulsado");
				acceder();
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnLogin.setForeground(new Color(0, 0, 0));
		btnLogin.setBackground(new Color(255, 0, 0));
		btnLogin.setBounds(296, 142, 89, 23);
		frmAccesoASistema.getContentPane().add(btnLogin);
	}
	private void acceder()
	{
		System.out.println("m�todo acceder");
		Connection miconexion = new Conexion().conectar();
		
		String consulta="SELECT * FROM user where username=? AND password=?";
		try {
			PreparedStatement ps = miconexion.prepareStatement(consulta);
			ps.setString(1, usuario_txt.getText());
			ps.setString(2, password_txt.getText());
			
			ResultSet rs = ps.executeQuery();
			
			//System.out.println(rs.next());//comprueba si el usuario existe
			
			if (rs.next()) {
				
				System.out.println("entra en if");
				
				Principal p = new Principal();
				p.setVisible(true); //mejor que show que est� depreciado
			} else {
				JOptionPane.showMessageDialog(null, "Login no v�lido");
			}
			ps.close();
			rs.close();
			miconexion.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}//cierra class











