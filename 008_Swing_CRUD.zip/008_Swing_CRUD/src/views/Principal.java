package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;

import controller.Conexion;
import model.User;

import javax.swing.JTextField;
import java.awt.Window.Type;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class Principal extends JFrame {

	private JFrame frmGestinDeUsuarios;
	private JTable table;
	private JTextField nombretxt;
	private JTextField passwordtxt;
	private JTextField estadotxt;

	Connection miConexion = new Conexion().conectar();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.frmGestinDeUsuarios.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principal() {
		cargar();
		verUsuarios(); //show_users()
		
	}//cierra constructor
	
	//crear m�todo listadoUsuarios
	public ArrayList<User> listadoUsuarios() {
		ArrayList<User> usuarios = new ArrayList<User>();
		
		try {
			Statement st =miConexion.createStatement();
			ResultSet rs = st.executeQuery("select * from user");
			
			User usuario;
			
			while(rs.next()) {
		usuario=new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
		usuarios.add(usuario);
			}//cierra while
			
			st.close();
			rs.close();
			miConexion.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return usuarios;
	}//cierra el m�todo listadoUsuarios

	/**
	 * Initialize the contents of the frame.
	 */
	private void cargar() {
		frmGestinDeUsuarios = new JFrame();
		frmGestinDeUsuarios.setAlwaysOnTop(true);
		frmGestinDeUsuarios.setForeground(Color.MAGENTA);
		frmGestinDeUsuarios.setTitle("Gesti\u00F3n de usuarios");
		frmGestinDeUsuarios.getContentPane().setBackground(Color.PINK);
		frmGestinDeUsuarios.setBounds(100, 100, 694, 432);
		frmGestinDeUsuarios.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmGestinDeUsuarios.getContentPane().setLayout(null);
		
		JLabel lblAccesoOk = new JLabel("Acceso ok");
		lblAccesoOk.setForeground(Color.RED);
		lblAccesoOk.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAccesoOk.setBounds(563, 334, 89, 31);
		frmGestinDeUsuarios.getContentPane().add(lblAccesoOk);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(21, 57, 355, 251);
		frmGestinDeUsuarios.getContentPane().add(panel);
		panel.setLayout(null);
		
		table = new JTable();
		table.setBackground(new Color(153, 153, 255));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"id", "usuario", "password", "estado"},
			},
			new String[] {
				"id", "usuario", "password", "estado"
			}
		) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.RED, null, null, null));
		table.setBounds(32, 60, 313, 180);
		panel.add(table);
		
		JLabel lblListadoDeUsuarios = new JLabel("Listado de usuarios");
		lblListadoDeUsuarios.setForeground(new Color(153, 0, 0));
		lblListadoDeUsuarios.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblListadoDeUsuarios.setBounds(48, 11, 173, 14);
		panel.add(lblListadoDeUsuarios);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.CYAN);
		panel_1.setBounds(418, 57, 218, 253);
		frmGestinDeUsuarios.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("nombre");
		lblNewLabel.setBounds(10, 14, 73, 14);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("contrase\u00F1a");
		lblNewLabel_1.setBounds(10, 46, 73, 14);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("estado");
		lblNewLabel_2.setBounds(10, 78, 73, 14);
		panel_1.add(lblNewLabel_2);
		
		nombretxt = new JTextField();
		nombretxt.setBounds(87, 8, 121, 20);
		panel_1.add(nombretxt);
		nombretxt.setColumns(10);
		
		passwordtxt = new JTextField();
		passwordtxt.setBounds(87, 40, 121, 20);
		panel_1.add(passwordtxt);
		passwordtxt.setColumns(10);
		
		estadotxt = new JTextField();
		estadotxt.setBounds(87, 72, 121, 20);
		panel_1.add(estadotxt);
		estadotxt.setColumns(10);
		
		JButton btnNewButton = new JButton("Nuevo");
		btnNewButton.setBounds(78, 18, 121, 23);
		frmGestinDeUsuarios.getContentPane().add(btnNewButton);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.setBounds(277, 18, 121, 23);
		frmGestinDeUsuarios.getContentPane().add(btnEliminar);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.setBounds(476, 18, 121, 23);
		frmGestinDeUsuarios.getContentPane().add(btnActualizar);
	}//cierra initialize
	
	private void verUsuarios() //cargar un modelo con los usuarios del AL
	//la tabla se llena con getModel
	{
		System.out.println("llamada a ver Usuarios");
		ArrayList<User> usuariosparatabla = listadoUsuarios();
		
		DefaultTableModel modelo = (DefaultTableModel) table.getModel();
		Object fila[]=new Object[4];
		for (int i = 0; i < usuariosparatabla.size(); i++) {
			fila[0]=usuariosparatabla.get(i).getId();
			fila[1]=usuariosparatabla.get(i).getUsername();
			fila[2]=usuariosparatabla.get(i).getPassword();
			fila[3]=usuariosparatabla.get(i).getUser_status();
			
			modelo.addRow(fila);
		}
		
		
	}
}//cierra class









